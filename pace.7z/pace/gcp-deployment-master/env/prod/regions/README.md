# Google Compute Resource Region

This folder is created for managing resouces as per their region in GCP. We can have multiple folder's created for each region.
